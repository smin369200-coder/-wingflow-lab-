WingFlow Lab v42

사이트 표시 이름:
WingFlow Lab — Wing Aerodynamics & CFD Visualization

변경사항:
- 브라우저 탭 제목 변경
- 페이지 상단 제목 변경
- 모델 유효성의 '초과' 표현을 '모델 범위 밖'으로 변경

GitHub Pages 배포:
이 index.html을 저장소 루트의 기존 index.html과 교체한 뒤 Commit changes 하면 됩니다.
